package com.example.mylauncher

import android.animation.ValueAnimator
import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.LayerDrawable
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.view.*
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.*
import java.util.Calendar

class MainActivity : Activity() {

    data class App(val label: String, val pkg: String, val icon: Drawable, val intent: Intent)
    class Th(val name: String, val g: List<Long>, val glass: Long, val rim: Long, val sheet: Long)

    private val themes = listOf(
        Th("Glass (your wallpaper)", listOf(), 0x22FFFFFF, 0x66FFFFFF, 0x44000000),
        Th("Aurora", listOf(0xFF1B1464, 0xFF3A6EA5, 0xFF2EC4B6), 0x2EFFFFFF, 0x77FFFFFF, 0x55101030),
        Th("Sunset", listOf(0xFF3D0C5C, 0xFFD6336C, 0xFFFF9F43), 0x2EFFFFFF, 0x77FFFFFF, 0x55300A30),
        Th("Midnight", listOf(0xFF05070F, 0xFF0F1B33, 0xFF1D2B53), 0x1AFFFFFF, 0x40FFFFFF, 0x66000000)
    )

    private val dp by lazy { resources.displayMetrics.density }
    private fun px(v: Int) = (v * dp).toInt()
    private fun c(v: Long) = v.toInt()
    private val prefs by lazy { getSharedPreferences("launcher", MODE_PRIVATE) }
    private val th by lazy { themes[prefs.getInt("theme", 1).coerceIn(0, themes.size - 1)] }

    private var all = listOf<App>()
    private var shown = listOf<App>()
    private lateinit var root: FrameLayout
    private lateinit var home: LinearLayout
    private lateinit var drawer: LinearLayout
    private lateinit var dock: LinearLayout
    private lateinit var recentRow: LinearLayout
    private lateinit var recentCard: LinearLayout
    private lateinit var grid: GridView
    private lateinit var search: EditText
    private lateinit var battery: TextView
    private lateinit var greet: TextView
    private lateinit var adapter: BaseAdapter
    private var drawerOpen = false
    private var animator: ValueAnimator? = null

    // ---------- Liquid-glass look ----------
    private fun glass(radii: FloatArray, tint: Long = th.glass): Drawable {
        val base = GradientDrawable().apply { cornerRadii = radii; setColor(c(tint)) }
        val sheen = GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(0x70FFFFFF, 0x10FFFFFF, 0x00FFFFFF, 0x28FFFFFF)
        ).apply { cornerRadii = radii }
        val rim = GradientDrawable().apply {
            cornerRadii = radii; setColor(Color.TRANSPARENT)
            setStroke(px(1).coerceAtLeast(1), c(th.rim))
        }
        return LayerDrawable(arrayOf(base, sheen, rim))
    }
    private fun glass(r: Int, tint: Long = th.glass) = glass(FloatArray(8) { r * dp }, tint)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        greet = TextView(this).apply { textSize = 15f; setTextColor(c(0xDDFFFFFF)) }
        val clock = TextClock(this).apply {
            format12Hour = "h:mm"; format24Hour = "HH:mm"
            textSize = 68f; setTextColor(Color.WHITE)
            typeface = Typeface.create("sans-serif-thin", Typeface.NORMAL)
            setShadowLayer(8f, 0f, 2f, 0x55000000)
        }
        val date = TextClock(this).apply {
            format12Hour = "EEEE, MMM d"; format24Hour = "EEEE, MMM d"
            textSize = 16f; setTextColor(c(0xEEFFFFFF))
        }
        battery = TextView(this).apply { textSize = 13f; setTextColor(c(0xBBFFFFFF)) }
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(px(24), px(16), px(24), px(18))
            background = glass(32)
            addView(greet); addView(clock); addView(date); addView(battery)
        }

        recentRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        recentCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(px(12), px(10), px(12), px(2))
            background = glass(28)
            addView(TextView(context).apply {
                text = "Recent"; textSize = 12f; setTextColor(c(0xBBFFFFFF)); setPadding(px(8), 0, 0, 0)
            })
            addView(recentRow)
        }
        val swipe = TextView(this).apply {
            text = "⌃  swipe up"; textSize = 12f; gravity = Gravity.CENTER; setTextColor(c(0x99FFFFFF))
        }
        dock = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER
            setPadding(px(10), px(6), px(10), px(6)); background = glass(36, c(0x2AFFFFFF).toLong())
        }
        home = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(card, LinearLayout.LayoutParams(-1, -2).apply { setMargins(px(16), px(24), px(16), 0) })
            addView(Space(context), LinearLayout.LayoutParams(-1, 0, 1f))
            addView(recentCard, LinearLayout.LayoutParams(-1, -2).apply { setMargins(px(16), 0, px(16), px(10)) })
            addView(swipe, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = px(6) })
            addView(dock, LinearLayout.LayoutParams(-1, -2).apply { setMargins(px(16), 0, px(16), px(16)) })
            setOnLongClickListener { homeMenu(); true }
        }

        // App drawer
        search = EditText(this).apply {
            hint = "Search apps or the web"; setSingleLine()
            setTextColor(Color.WHITE); setHintTextColor(c(0x99FFFFFF))
            background = glass(28, 0x30FFFFFF)
            setPadding(px(20), px(12), px(20), px(12))
            imeOptions = EditorInfo.IME_ACTION_GO
            addTextChangedListener(object : TextWatcher {
                override fun afterTextChanged(s: Editable?) = filter(s.toString())
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            })
            setOnEditorActionListener { _, _, _ ->
                val q = text.toString()
                val f = shown.firstOrNull()
                if (f != null) launch(f)
                else if (q.isNotBlank()) startActivity(
                    Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(q))))
                true
            }
        }
        adapter = object : BaseAdapter() {
            override fun getCount() = shown.size
            override fun getItem(i: Int) = shown[i]
            override fun getItemId(i: Int) = i.toLong()
            override fun getView(i: Int, v: View?, p: ViewGroup?) = tile(shown[i], true)
        }
        grid = GridView(this).apply {
            numColumns = 4; adapter = this@MainActivity.adapter
            setOnItemClickListener { _, _, i, _ -> launch(shown[i]) }
            setOnItemLongClickListener { _, _, i, _ -> menu(shown[i]); true }
        }
        val handle = View(this).apply { background = glass(2, 0x99FFFFFF) }
        val sheetR = floatArrayOf(36 * dp, 36 * dp, 36 * dp, 36 * dp, 0f, 0f, 0f, 0f)
        drawer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; visibility = View.GONE
            background = glass(sheetR, th.sheet)
            setPadding(px(12), px(10), px(12), 0)
            addView(handle, LinearLayout.LayoutParams(px(40), px(4)).apply {
                gravity = Gravity.CENTER_HORIZONTAL; bottomMargin = px(12)
            })
            addView(search, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = px(8) })
            addView(grid, LinearLayout.LayoutParams(-1, 0, 1f))
        }

        root = FrameLayout(this).apply {
            addView(home, FrameLayout.LayoutParams(-1, -1))
            addView(drawer, FrameLayout.LayoutParams(-1, -1).apply { topMargin = px(56) })
            setOnApplyWindowInsetsListener { v, insets ->
                val b = insets.getInsets(WindowInsets.Type.systemBars())
                v.setPadding(0, b.top, 0, b.bottom); insets
            }
        }
        if (th.g.isNotEmpty()) {
            root.background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR, th.g.map { c(it) }.toIntArray())
        }
        setContentView(root)
    }

    // ---------- Gestures ----------
    private val gestures by lazy {
        GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onFling(a: MotionEvent?, b: MotionEvent, vx: Float, vy: Float): Boolean {
                if (!drawerOpen && vy < -1200) { setDrawer(true); return true }
                val atTop = grid.firstVisiblePosition == 0 && (grid.getChildAt(0)?.top ?: 0) >= 0
                if (drawerOpen && vy > 1200 && atTop) { setDrawer(false); return true }
                return false
            }
        })
    }
    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        gestures.onTouchEvent(ev); return super.dispatchTouchEvent(ev)
    }

    private fun setBlur(r: Int) {
        if (th.g.isEmpty()) try { window.setBackgroundBlurRadius(r) } catch (_: Throwable) {}
    }

    private fun setDrawer(open: Boolean) {
        if (open == drawerOpen) return
        drawerOpen = open
        animator?.cancel()
        if (open) drawer.visibility = View.VISIBLE
        else (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
            .hideSoftInputFromWindow(search.windowToken, 0)
        val h = root.height.toFloat()
        animator = ValueAnimator.ofFloat(if (open) 0f else 1f, if (open) 1f else 0f).apply {
            duration = 320
            interpolator = android.view.animation.DecelerateInterpolator(1.6f)
            addUpdateListener {
                val f = it.animatedValue as Float
                drawer.translationY = h * (1 - f)
                home.alpha = 1f - 0.5f * f; home.scaleX = 1f - 0.04f * f; home.scaleY = home.scaleX
                setBlur((f * 90).toInt())
            }
            addListener(object : android.animation.AnimatorListenerAdapter() {
                override fun onAnimationEnd(a: android.animation.Animator) {
                    if (!drawerOpen) { drawer.visibility = View.GONE; search.setText("") }
                }
            })
            start()
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() { if (drawerOpen) setDrawer(false) }
    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent); if (drawerOpen) setDrawer(false)
    }

    override fun onResume() {
        super.onResume()
        load(); fill(dock, dockPkgs()); fill(recentRow, recent())
        recentCard.visibility = if (recentRow.childCount == 0) View.GONE else View.VISIBLE
        updateBattery(); greet.text = greeting()
    }

    // ---------- Data ----------
    private fun load() {
        val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        all = packageManager.queryIntentActivities(q, 0)
            .filter { it.activityInfo.packageName != packageName }
            .mapNotNull {
                val i = packageManager.getLaunchIntentForPackage(it.activityInfo.packageName)
                    ?: return@mapNotNull null
                App(it.loadLabel(packageManager).toString(), it.activityInfo.packageName, it.loadIcon(packageManager), i)
            }
            .distinctBy { it.pkg }.sortedBy { it.label.lowercase() }
        filter(search.text.toString())
    }
    private fun filter(q: String) {
        val hid = hidden()
        val base = all.filter { it.pkg !in hid }
        shown = if (q.isBlank()) base else base.filter { it.label.contains(q, true) }
        adapter.notifyDataSetChanged()
    }
    private fun greeting(): String {
        val h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        return when { h < 5 -> "Good night"; h < 12 -> "Good morning"; h < 18 -> "Good afternoon"; else -> "Good evening" }
    }
    private fun updateBattery() {
        val i = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)) ?: return
        val pct = i.getIntExtra(BatteryManager.EXTRA_LEVEL, 0) * 100 / i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
        val chg = i.getIntExtra(BatteryManager.EXTRA_STATUS, 0) == BatteryManager.BATTERY_STATUS_CHARGING
        battery.text = "Battery $pct%" + if (chg) " ⚡" else ""
    }
    private fun list(key: String) = (prefs.getString(key, "") ?: "").split(",").filter { it.isNotEmpty() }
    private fun hidden() = list("hidden")
    private fun recent() = list("recent")
    private fun setHidden(pkg: String, hide: Boolean) {
        val l = hidden().toMutableList(); l.remove(pkg); if (hide) l.add(pkg)
        prefs.edit().putString("hidden", l.joinToString(",")).apply()
        filter(search.text.toString())
    }

    // ---------- Dock / recents ----------
    private fun dockPkgs(): List<String> {
        val s = prefs.getString("dock", null)
        if (s != null) return s.split(",").filter { it.isNotEmpty() }
        return listOf(
            Intent(Intent.ACTION_DIAL), Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:")),
            Intent(Intent.ACTION_VIEW, Uri.parse("https://")), Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        ).mapNotNull { packageManager.resolveActivity(it, PackageManager.MATCH_DEFAULT_ONLY)?.activityInfo?.packageName }
            .filter { p -> all.any { it.pkg == p } }.distinct()
    }
    private fun fill(row: LinearLayout, pkgs: List<String>) {
        row.removeAllViews()
        pkgs.mapNotNull { p -> all.firstOrNull { it.pkg == p } }.forEach { app ->
            row.addView(tile(app, false).apply {
                setOnClickListener { launch(app) }
                setOnLongClickListener { menu(app); true }
            }, LinearLayout.LayoutParams(0, -2, 1f))
        }
        row.visibility = if (row.childCount == 0) View.GONE else View.VISIBLE
    }
    private fun togglePin(pkg: String) {
        val l = dockPkgs().toMutableList()
        if (!l.remove(pkg)) { if (l.size >= 5) l.removeAt(0); l.add(pkg) }
        prefs.edit().putString("dock", l.joinToString(",")).apply(); fill(dock, dockPkgs())
    }

    // ---------- UI helpers ----------
    private fun tile(app: App, labels: Boolean): LinearLayout {
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            setPadding(0, px(10), 0, px(10))
            setOnTouchListener { v, e ->
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> v.animate().scaleX(.88f).scaleY(.88f).setDuration(90).start()
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                        v.animate().scaleX(1f).scaleY(1f).setDuration(140).start()
                }
                false
            }
        }
        col.addView(ImageView(this).apply {
            setImageDrawable(app.icon)
            background = glass(16, 0x1CFFFFFF)
            setPadding(px(7), px(7), px(7), px(7))
            layoutParams = LinearLayout.LayoutParams(px(58), px(58))
        })
        if (labels) col.addView(TextView(this).apply {
            text = app.label; textSize = 12f; maxLines = 1; gravity = Gravity.CENTER
            setTextColor(Color.WHITE); setShadowLayer(4f, 0f, 1f, Color.BLACK)
            setPadding(px(2), px(4), px(2), 0)
        })
        return col
    }
    private fun launch(app: App) {
        val l = recent().toMutableList(); l.remove(app.pkg); l.add(0, app.pkg)
        prefs.edit().putString("recent", l.take(4).joinToString(",")).apply()
        startActivity(app.intent)
        setDrawer(false)
    }
    private fun menu(app: App) {
        window.decorView.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
        val pinned = app.pkg in dockPkgs()
        AlertDialog.Builder(this).setTitle(app.label)
            .setItems(arrayOf(if (pinned) "Remove from dock" else "Pin to dock", "Hide app", "App info", "Uninstall")) { _, w ->
                val uri = Uri.parse("package:${app.pkg}")
                when (w) {
                    0 -> togglePin(app.pkg)
                    1 -> setHidden(app.pkg, true)
                    2 -> startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, uri))
                    3 -> startActivity(Intent(Intent.ACTION_DELETE, uri))
                }
            }.show()
    }
    private fun homeMenu() {
        window.decorView.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
        AlertDialog.Builder(this)
            .setItems(arrayOf("Change theme", "Wallpaper", "Hidden apps", "Phone settings")) { _, w ->
                when (w) {
                    0 -> themeDialog()
                    1 -> startActivity(Intent.createChooser(Intent(Intent.ACTION_SET_WALLPAPER), "Wallpaper"))
                    2 -> hiddenDialog()
                    3 -> startActivity(Intent(Settings.ACTION_SETTINGS))
                }
            }.show()
    }
    private fun themeDialog() {
        AlertDialog.Builder(this).setTitle("Theme")
            .setSingleChoiceItems(themes.map { it.name }.toTypedArray(), prefs.getInt("theme", 1)) { d, i ->
                prefs.edit().putInt("theme", i).apply(); d.dismiss(); recreate()
            }.show()
    }
    private fun hiddenDialog() {
        val hs = all.filter { it.pkg in hidden() }
        if (hs.isEmpty()) { Toast.makeText(this, "No hidden apps", Toast.LENGTH_SHORT).show(); return }
        AlertDialog.Builder(this).setTitle("Tap an app to unhide")
            .setItems(hs.map { it.label }.toTypedArray()) { _, i -> setHidden(hs[i].pkg, false) }.show()
    }
}
